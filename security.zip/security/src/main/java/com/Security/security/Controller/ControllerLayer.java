package com.Security.security.Controller;

import com.Security.security.Entity.User;
import com.Security.security.Entity.jwtRequest;
import com.Security.security.Entity.jwtResponse;
import com.Security.security.ServiceLayer.customUserDetailService;
import com.Security.security.ServiceLayer.serviceLayer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ControllerLayer {

    @Autowired
    private AuthenticationManager authenticationManager;
    @Autowired
    private com.Security.security.jwtUtility.jwtUtil jwtUtil;


    @Autowired
       private customUserDetailService service;
    serviceLayer serviceLayer;

    public ControllerLayer(com.Security.security.ServiceLayer.serviceLayer serviceLayer) {
        this.serviceLayer = serviceLayer;
    }


    @PostMapping("/authenticate")
    public ResponseEntity<?> Details(@RequestBody jwtRequest jRequest) throws Exception {
        System.out.println("inside /authenticate");
        try {
            this.authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(
                    jRequest.getUsername(),jRequest.getPassword()
            ));

        }catch(Exception e )
        {
            e.printStackTrace();
            throw new Exception(" bad Credentials");
        }

        System.out.println("inside /authenticate");

        final UserDetails userDetails = service.loadUserByUsername(jRequest.getUsername());
        final String Token = jwtUtil.generateToken(userDetails);
        System.out.println("token = " + Token);
        return  ResponseEntity.ok(new jwtResponse(Token));
    }

    @GetMapping("/")
    public String ShowHome(){
        return ("<h2> welcome </h2>");
    }



    @PostMapping("/user/add")
    public String ShowUser(@RequestBody User user){
        System.out.println(user.toString());
        serviceLayer.saveUser(user);
        return "success";
    }
}
