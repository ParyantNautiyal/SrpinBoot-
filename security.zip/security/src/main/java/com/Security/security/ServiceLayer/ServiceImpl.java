package com.Security.security.ServiceLayer;

import com.Security.security.Entity.User;
import com.Security.security.Repository.repo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class ServiceImpl implements serviceLayer {

    repo r;
    @Autowired
    PasswordEncoder passwordEncoder;

    public ServiceImpl(repo r) {
        this.r = r;
    }

    @Override
    public void saveUser(User user) {
       User u =new User();
       System.out.println("user  = " + user.toString());
       u.setUsername(user.getUsername());
       u.setEmail(user.getEmail());
       u.setRole(user.getRole());
       u.setEnabled(user.isEnabled());
       u.setPassword(passwordEncoder.encode(user.getPassword()));
       r.save(u);
    }

}
