package com.Security.security.ServiceLayer;

import com.Security.security.Entity.User;
import com.Security.security.Entity.userDetails;
import com.Security.security.Repository.repo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Optional;
@Service
public class customUserDetailService implements UserDetailsService {
    @Autowired
    repo r;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

        if(this.r.findById(username).isEmpty()) throw new UsernameNotFoundException("User not found");

        User u = this.r.findById(username).get();

        return new userDetails(u);
    }
    }

